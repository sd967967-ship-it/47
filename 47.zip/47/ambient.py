"""
Ambient awareness — the thing that makes 47 feel "always on" rather than
purely reactive. Runs in the background, polls system vitals, and streams
them to the dashboard continuously (like a HUD).

Uses psutil (free, offline). pip install psutil
"""

import time
import psutil


def get_system_snapshot() -> dict:
    battery = psutil.sensors_battery()
    net = psutil.net_io_counters()
    return {
        "cpu_percent": psutil.cpu_percent(interval=0.3),
        "ram_percent": psutil.virtual_memory().percent,
        "disk_percent": psutil.disk_usage("/").percent,
        "battery_percent": battery.percent if battery else None,
        "battery_plugged": battery.power_plugged if battery else None,
        "net_sent_mb": round(net.bytes_sent / 1e6, 1),
        "net_recv_mb": round(net.bytes_recv / 1e6, 1),
        "process_count": len(psutil.pids()),
    }


def ambient_loop(push_fn, interval_seconds: int = 5, alert_fn=None):
    """
    Continuously push system vitals to the dashboard.
    push_fn(kind, payload) -> same signature as main.push_to_dashboard
    alert_fn(message) -> optional callback (e.g. speak()) for threshold alerts
    """
    warned_cpu = False
    warned_battery = False

    while True:
        snap = get_system_snapshot()
        push_fn("vitals", snap)

        # Simple proactive alerts (ambient intelligence, not just reactive)
        if alert_fn:
            if snap["cpu_percent"] > 90 and not warned_cpu:
                alert_fn("Heads up — CPU usage is very high right now.")
                warned_cpu = True
            elif snap["cpu_percent"] < 70:
                warned_cpu = False

            if snap["battery_percent"] is not None and snap["battery_percent"] < 15 \
                    and not snap["battery_plugged"] and not warned_battery:
                alert_fn("Your battery is below 15 percent and not charging.")
                warned_battery = True
            elif snap["battery_percent"] is None or snap["battery_percent"] > 20:
                warned_battery = False

        time.sleep(interval_seconds)
