"""
47 action modules — the "hands" of the assistant.
All free, local, no paid APIs required (email needs a one-time free
Google Cloud OAuth setup, no cost).
"""

import os
import platform
import re
import subprocess
import webbrowser
import requests
from pathlib import Path
from urllib.parse import quote_plus

from net_utils import request_with_retry


# ---------- Open apps / websites ----------
KNOWN_SITES = {
    "youtube": "https://youtube.com",
    "gmail": "https://mail.google.com",
    "google": "https://google.com",
    "github": "https://github.com",
}

# Local tools that need special-cased launch commands rather than a plain
# app name (a real terminal, not "run a command inside a hidden shell" —
# see shell.py for that). Keyed by every spoken alias that should match.
_TERMINAL_ALIASES = {
    "terminal", "cmd", "command prompt", "powershell", "shell", "console",
}
_FILE_MANAGER_ALIASES = {"file explorer", "explorer", "finder", "files"}


def _open_terminal() -> str:
    # BUGFIX: the Linux branch used to claim "Opening a terminal." even
    # when every one of gnome-terminal/konsole/xterm was missing (the
    # for-loop just fell through with no error). Now it actually tracks
    # whether any launch succeeded and says so honestly if none did.
    system = platform.system()
    try:
        if system == "Windows":
            subprocess.Popen(["cmd.exe"])
        elif system == "Darwin":
            subprocess.Popen(["open", "-a", "Terminal"])
        else:
            launched = False
            for term in ("gnome-terminal", "konsole", "xterm"):
                try:
                    subprocess.Popen([term])
                    launched = True
                    break
                except FileNotFoundError:
                    continue
            if not launched:
                return ("Couldn't open a terminal: none of gnome-terminal, "
                        "konsole, or xterm are installed.")
        return "Opening a terminal."
    except Exception as e:
        return f"Couldn't open a terminal: {e}"


def _open_file_manager() -> str:
    system = platform.system()
    try:
        if system == "Windows":
            subprocess.Popen(["explorer.exe"])
        elif system == "Darwin":
            subprocess.Popen(["open", str(Path.home())])
        else:
            subprocess.Popen(["xdg-open", str(Path.home())])
        return "Opening the file manager."
    except Exception as e:
        return f"Couldn't open the file manager: {e}"


def open_app_or_site(target: str) -> str:
    target = target.strip()
    lowered = target.lower()

    if lowered in _TERMINAL_ALIASES:
        return _open_terminal()
    if lowered in _FILE_MANAGER_ALIASES:
        return _open_file_manager()
    if lowered in KNOWN_SITES:
        webbrowser.open(KNOWN_SITES[lowered])
        return f"Opening {target}."

    if target.endswith(".com") or target.startswith("http"):
        url = target if target.startswith("http") else f"https://{target}"
        webbrowser.open(url)
        return f"Opening {target}."

    # Try to launch as a local application
    system = platform.system()
    try:
        if system == "Windows":
            os.startfile(target)  # noqa
        elif system == "Darwin":
            subprocess.Popen(["open", "-a", target])
        else:
            subprocess.Popen([target.lower()])
        return f"Opening {target}."
    except Exception:
        return f"I couldn't find an app or site called {target}."


# ---------- Fetch any web page (free, no API key: plain GET + tag-strip) ----------
_URL_RE = re.compile(r"https?://\S+")


def find_url(text: str) -> str:
    """Pull the first http(s) URL out of a sentence, if any."""
    match = _URL_RE.search(text)
    return match.group(0).rstrip(".,)") if match else None


def fetch_url(url: str, max_chars: int = 4000) -> str:
    """GET a URL and return roughly-cleaned plain text (script/style
    stripped, tags stripped, whitespace collapsed). No JS rendering — this
    is a plain HTTP fetch, so JS-only pages may come back mostly empty."""
    try:
        resp = request_with_retry(
            "GET", url, timeout=15,
            headers={"User-Agent": "Mozilla/5.0 (47-assistant/1.0)"},
        )
        resp.raise_for_status()
        html = resp.text
        html = re.sub(r"(?is)<(script|style).*?</\1>", " ", html)
        text = re.sub(r"(?s)<[^>]+>", " ", html)
        text = re.sub(r"\s+", " ", text).strip()
        return text[:max_chars] or "(fetched the page but it had no readable text)"
    except Exception as e:
        return f"Couldn't fetch that page: {e}"


# ---------- Live weather (free, no API key: Open-Meteo) ----------
def get_weather(place: str) -> str:
    """Real-time weather for a place name, via Open-Meteo (free, no key,
    two calls: geocode the place name, then fetch current conditions)."""
    try:
        geo = request_with_retry(
            "GET", "https://geocoding-api.open-meteo.com/v1/search",
            params={"name": place, "count": 1}, timeout=10,
        ).json()
        results = geo.get("results")
        if not results:
            return f"I couldn't find a place called {place}."
        loc = results[0]
        lat, lon = loc["latitude"], loc["longitude"]
        label = f"{loc.get('name', place)}, {loc.get('country', '')}".strip(", ")

        wx = request_with_retry(
            "GET", "https://api.open-meteo.com/v1/forecast",
            params={"latitude": lat, "longitude": lon, "current_weather": True},
            timeout=10,
        ).json()
        current = wx.get("current_weather", {})
        temp = current.get("temperature")
        wind = current.get("windspeed")
        if temp is None:
            return f"Couldn't get current conditions for {label}."
        return f"Right now in {label}: {temp}°C, wind {wind} km/h."
    except Exception as e:
        return f"Couldn't fetch the weather: {e}"


# ---------- Web search (free, no API key: DuckDuckGo instant answers) ----------
def web_search(query: str):
    url = f"https://api.duckduckgo.com/?q={quote_plus(query)}&format=json&no_html=1"
    try:
        r = request_with_retry("GET", url, timeout=10).json()
        results = []
        for topic in r.get("RelatedTopics", [])[:5]:
            if "Text" in topic:
                results.append({"title": topic["Text"], "url": topic.get("FirstURL", "")})
        if not results and r.get("AbstractText"):
            results.append({"title": r["AbstractText"], "url": r.get("AbstractURL", "")})
        return results or [{"title": f"No instant answer for '{query}'", "url": ""}]
    except Exception as e:
        return [{"title": f"Search failed: {e}", "url": ""}]


# ---------- File search (deeper OS control) ----------
def find_files(name_fragment: str, search_root: str = None, max_results: int = 15):
    """Search the filesystem for files whose name contains name_fragment."""
    root = Path(search_root) if search_root else Path.home()
    fragment = name_fragment.lower()
    matches = []
    try:
        for path in root.rglob("*"):
            if fragment in path.name.lower():
                matches.append(str(path))
                if len(matches) >= max_results:
                    break
    except PermissionError:
        pass
    return matches


def open_file(path: str) -> str:
    system = platform.system()
    try:
        if system == "Windows":
            os.startfile(path)  # noqa
        elif system == "Darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
        return f"Opening {path}."
    except Exception as e:
        return f"Couldn't open {path}: {e}"


# ---------- System controls (volume) ----------
def set_volume(level_percent: int) -> str:
    """Best-effort cross-platform volume control (0-100)."""
    level_percent = max(0, min(100, level_percent))
    system = platform.system()
    try:
        if system == "Darwin":
            subprocess.run(["osascript", "-e", f"set volume output volume {level_percent}"])
        elif system == "Windows":
            # Requires: pip install pycaw comtypes
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMasterVolumeLevelScalar(level_percent / 100, None)
        else:
            subprocess.run(["amixer", "-D", "pulse", "sset", "Master", f"{level_percent}%"])
        return f"Volume set to {level_percent} percent."
    except Exception as e:
        return f"Couldn't change volume: {e}"


# ---------- Email (free — Gmail API, needs one-time OAuth setup) ----------
def send_email(to: str, subject: str, body: str):
    """
    SETUP (one-time, free):
    1. Go to console.cloud.google.com -> create project -> enable Gmail API
    2. Create OAuth credentials -> download credentials.json into this folder
    3. pip install google-auth-oauthlib google-api-python-client
    4. First run will open a browser to authorize your Google account
    This stub is left unimplemented until you complete that setup.
    """
    raise NotImplementedError("Complete the Gmail API setup above, then implement this.")
