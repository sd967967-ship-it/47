import unittest

import visual3d


class TestClassify(unittest.TestCase):
    def test_building(self):
        self.assertEqual(visual3d.classify("what does a skyscraper look like"), "building")

    def test_new_electronics_category(self):
        self.assertEqual(visual3d.classify("what does my laptop look like"), "electronics")

    def test_new_nature_category(self):
        self.assertEqual(visual3d.classify("what does a tree look like"), "nature")

    def test_new_furniture_category(self):
        self.assertEqual(visual3d.classify("show me a chair"), "furniture")

    def test_graph_keywords_win_over_object_keywords(self):
        # "compare" should route to bar/network charts, not a 3D shape,
        # even though "car" would otherwise match the vehicle category.
        self.assertIsNone(visual3d.classify("compare a car and a truck"))

    def test_no_match_returns_none(self):
        self.assertIsNone(visual3d.classify("what's the capital of France"))

    def test_build_payload_shape(self):
        kind, payload = visual3d.build_payload("furniture", "show me a chair")
        self.assertEqual(kind, "object3d")
        self.assertEqual(payload["type"], "furniture")
        self.assertEqual(payload["label"], "Show me a chair")

    def test_build_payload_none_category(self):
        self.assertEqual(visual3d.build_payload(None, "irrelevant"), (None, None))


if __name__ == "__main__":
    unittest.main()
